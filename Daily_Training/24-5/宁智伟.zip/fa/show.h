#include <bits/stdc++.h>

void shows(std::string s);

void showvs(std::vector<std::string> s);

void showvs_w(std::vector<std::string> s);